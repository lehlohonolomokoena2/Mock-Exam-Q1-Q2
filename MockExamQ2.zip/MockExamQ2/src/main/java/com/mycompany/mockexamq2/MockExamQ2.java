/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mockexamq2;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.*;
import java.util.List;

/**
 *
 * @author Lehlohonolo.Mokoena
 */
// Interface
interface IProductSales {

    int[][] GetProductSales();

    int GetTotalSales();

    int GetSalesOverLimit();

    int GetSalesUnderLimit();

    int GetProductsProcessed();

    double GetAverageSales();
}

// ProductSales class
class ProductSales implements IProductSales {

    private int[][] productSales = {
        {300, 150, 700},
        {250, 200, 600}
    };

    private final int SALES_LIMIT = 500;

    @Override
    public int[][] GetProductSales() {
        return productSales;
    }

    @Override
    public int GetTotalSales() {

        int total = 0;

        for (int i = 0; i < productSales.length; i++) {
            for (int j = 0; j < productSales[i].length; j++) {
                total += productSales[i][j];
            }
        }

        return total;
    }

    @Override
    public int GetSalesOverLimit() {

        int count = 0;

        for (int i = 0; i < productSales.length; i++) {
            for (int j = 0; j < productSales[i].length; j++) {

                if (productSales[i][j] > SALES_LIMIT) {
                    count++;
                }
            }
        }

        return count;
    }

    @Override
    public int GetSalesUnderLimit() {

        int count = 0;

        for (int i = 0; i < productSales.length; i++) {
            for (int j = 0; j < productSales[i].length; j++) {

                if (productSales[i][j] < SALES_LIMIT) {
                    count++;
                }
            }
        }

        return count;
    }

    @Override
    public int GetProductsProcessed() {
        return productSales.length;
    }

    @Override
    public double GetAverageSales() {

        int total = GetTotalSales();

        int count = 0;

        for (int i = 0; i < productSales.length; i++) {
            count += productSales[i].length;
        }

        return (double) total / count;
    }
}
public class MockExamQ2 extends JFrame {
    private JTextArea displayArea;
    private JLabel yearsLabel;

    private ProductSales ps = new ProductSales();

    public MockExamQ2() {

        setTitle("Product Sales Application");
        setSize(460, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Menu bar
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenu toolsMenu = new JMenu("Tools");

        JMenuItem exitItem = new JMenuItem("Exit");
        JMenuItem loadItem = new JMenuItem("Load Product Data");
        JMenuItem saveItem = new JMenuItem("Save Product Data");
        JMenuItem clearItem = new JMenuItem("Clear");

        // Menu actions
        exitItem.addActionListener(e -> System.exit(0));
        loadItem.addActionListener(e -> loadData());
        saveItem.addActionListener(e -> saveData());
        clearItem.addActionListener(e -> clearData());

        fileMenu.add(exitItem);

        toolsMenu.add(loadItem);
        toolsMenu.add(saveItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);

        setJMenuBar(menuBar);

        // Main panel
        JPanel panel = new JPanel();

        panel.setLayout(new BorderLayout(10, 10));

        panel.setBorder(
            BorderFactory.createEmptyBorder(15, 30, 15, 30)
        );

        // Buttons
        JButton loadButton =
                new JButton("Load Product Data");

        JButton saveButton =
                new JButton("Save Product Data");

        loadButton.addActionListener(e -> loadData());
        saveButton.addActionListener(e -> saveData());

        // Button panel
        JPanel buttonPanel =
                new JPanel(new GridLayout(2, 1, 10, 10));

        buttonPanel.add(loadButton);
        buttonPanel.add(saveButton);

        // Text area
        displayArea = new JTextArea(8, 30);

        displayArea.setEditable(false);

        displayArea.setFont(
                new Font("Arial", Font.PLAIN, 14)
        );

        JScrollPane scrollPane =
                new JScrollPane(displayArea);

        // Years label
        yearsLabel = new JLabel("Years Processed: 0");

        // Add components
        panel.add(buttonPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(yearsLabel, BorderLayout.SOUTH);

        add(panel);
    }

    // Load product sales data
    private void loadData() {

        int[][] sales = ps.GetProductSales();

        StringBuilder output = new StringBuilder();

//        output.append("Product Sales Data\n");
//        output.append("--------------------------\n");
//        output.append("Microphone  Speakers  Mixing Desk\n");
//
//        for (int i = 0; i < sales.length; i++) {
//
//            output.append("Year ").append(i + 1).append("     ");
//
//            for (int j = 0; j < sales[i].length; j++) {
//
//                output.append(sales[i][j]).append("       ");
//            }
//
//            output.append("\n");
//        }
//
//        output.append("\n");


output.append("DATA LOG");

        // Display calculations
        output.append("Total Sales: R")
                .append(ps.GetTotalSales()).append("\n");

        output.append("Average Sales: R")
                .append(String.format("%.2f",
                        ps.GetAverageSales())).append("\n");

        output.append("Sales over limit: ")
                .append(ps.GetSalesOverLimit()).append("\n");

        output.append("Sales under limit: ")
                .append(ps.GetSalesUnderLimit());

        displayArea.setText(output.toString());

        yearsLabel.setText(
                "Years Processed: " +
                ps.GetProductsProcessed()
        );
    }

    // Save product data
    private void saveData() {

        if (displayArea.getText().isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "There is no data to save!"
            );

            return;
        }

        try (PrintWriter writer =
                new PrintWriter(new FileWriter("data.txt"))) {

            writer.print(displayArea.getText());

            JOptionPane.showMessageDialog(
                    this,
                    "Data saved successfully to data.txt!"
            );

        } catch (IOException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error saving data: " + ex.getMessage()
            );
        }
    }

    // Clear data
    private void clearData() {

        displayArea.setText("");

        yearsLabel.setText("Years Processed: 0");
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {

            MockExamQ2 app =
                    new MockExamQ2();

            app.setVisible(true);
        });
    }
}

