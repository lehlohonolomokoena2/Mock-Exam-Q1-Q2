/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mockexamq1;

/**
 *
 * @author Lehlohonolo.Mokoena
 */
public class MockExamQ1 {
 // Interface
    interface IProductSales {

        int TotalSales(int[][] productSales);

        double AverageSales(int[][] productSales);

        int MaxSale(int[][] productSales);

        int MinSale(int[][] productSales);
    }

    // ProductSales class implements the interface
    static class ProductSales implements IProductSales {

        @Override
        public int TotalSales(int[][] productSales) {

            int total = 0;

            for (int i = 0; i < productSales.length; i++) {
                for (int j = 0; j < productSales[i].length; j++) {

                    total += productSales[i][j];
                }
            }

            return total;
        }

        @Override
        public double AverageSales(int[][] productSales) {

            int total = TotalSales(productSales);
            int count = 0;

            for (int i = 0; i < productSales.length; i++) {
                count += productSales[i].length;
            }

            return (double) total / count;
        }

        @Override
        public int MaxSale(int[][] productSales) {

            int maximum = productSales[0][0];

            for (int i = 0; i < productSales.length; i++) {
                for (int j = 0; j < productSales[i].length; j++) {

                    if (productSales[i][j] > maximum) {
                        maximum = productSales[i][j];
                    }
                }
            }

            return maximum;
        }

        @Override
        public int MinSale(int[][] productSales) {

            int minimum = productSales[0][0];

            for (int i = 0; i < productSales.length; i++) {
                for (int j = 0; j < productSales[i].length; j++) {

                    if (productSales[i][j] < minimum) {
                        minimum = productSales[i][j];
                    }
                }
            }

            return minimum;
        }
    }




    public static void main(String[] args) {
               // Two-dimensional array
        int[][] productSales = {
            {300, 150, 700},
            {250, 200, 600}
        };

        // Create ProductSales object
        ProductSales ps = new ProductSales();

        // Display heading
        System.out.println("PRODUCT SALES REPORT");
        System.out.println("--------------------");

        // Display total sales
        System.out.println("Total Sales: R"
                + ps.TotalSales(productSales));

        // Display average sales
        System.out.println("Average Sales: R"
                + Math.round(ps.AverageSales(productSales)));

        // Display maximum sale
        System.out.println("Maximum Sale: R"
                + ps.MaxSale(productSales));

        // Display minimum sale
        System.out.println("Minimum Sale: R"
                + ps.MinSale(productSales));

        // Single-dimensional array
        int[] allSales = new int[6];

        int index = 0;

        // Copy the 2D array values into the 1D array
        for (int i = 0; i < productSales.length; i++) {
            for (int j = 0; j < productSales[i].length; j++) {

                allSales[index] = productSales[i][j];
                index++;
            }
        }

        // Display all sales
        System.out.println();
        System.out.println("ALL PRODUCT SALES");
        System.out.println("-----------------");

        for (int i = 0; i < allSales.length; i++) {
            System.out.println("Sale " + (i + 1) + ": R" + allSales[i]);
        }
    }
}
    
    


